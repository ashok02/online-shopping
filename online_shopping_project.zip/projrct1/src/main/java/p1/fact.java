package p1;

public class fact {
static int fact(int n)
{
if(n==0)
	return 1;
else
	return(n*fact(n-1));
}
public static void main(String[] args) {
int n=6;
int x=fact(n);
System.out.println("fact of given number is:"+x);
}
}
